library(testthat)
library(RWDataPlyr)

test_check("RWDataPlyr")

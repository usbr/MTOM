library(testthat)
library(CoRiverNF)

test_check("CoRiverNF")

library(testthat)
library(CRSSIO)

test_check("CRSSIO")

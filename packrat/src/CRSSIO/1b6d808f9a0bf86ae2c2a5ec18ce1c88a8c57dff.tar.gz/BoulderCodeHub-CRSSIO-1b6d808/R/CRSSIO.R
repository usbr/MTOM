
#' @keywords internal
"_PACKAGE"

#' @importFrom magrittr "%>%"
#' @importFrom rlang .data
NULL
